﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace TcpConsoleApplication1
{
    class Program
    {
        static Socket server=new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);

        static void Main(string[] args)
        {
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[3];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 17494);
            byte RelayState = 0x55;// 0x00;

            server.Bind(localEndPoint);
            server.Listen(100);
            while (true)
            {
                Console.WriteLine("Waiting for a connection...");
                Socket handler = server.Accept();
                String data = null;

                while (handler.Connected)
                {
                    var bytes = new byte[1024];
                    int bytesRec;

                    try
                    {
                        bytesRec = handler.Receive(bytes);
                    }
                    catch
                    { break; }
                    if (bytesRec == 0)
                        break;
                    data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                    switch (bytes[0])
                    {
                        case 0x5a:
                            Console.WriteLine("Version Request received : 0x5A");
                            handler.Send(new byte[] { 0x07 });
                            break;
                        case 0x5b:
                            Console.WriteLine("Relay State Request received : 0x5B");
                            handler.Send(new byte[] { RelayState });
                            break;
                        case 0x5c:
                            Console.WriteLine("Set Relay State Request received : 0x5C");
                            RelayState = bytes[1];
                            break;
                        case 0x5d:
                            Console.WriteLine("Get Relay Voltage State Request received : 0x5D");
                            handler.Send(new byte[] { 0x7D });
                            break;
                        case 0x64:
                            Console.WriteLine("All Relays on: 0x64");
                            RelayState = 0xFF;
                            break;
                        case 0x65:
                            Console.WriteLine("Relay 1 on: 0x65");
                            RelayState |= 0x01;
                            break;
                        case 0x66:
                            Console.WriteLine("Relay 2 on: 0x66");
                            RelayState |= 0x02;
                            break;
                        case 0x67:
                            Console.WriteLine("Relay 3 on: 0x67");
                            RelayState |= 0x04;
                            break;
                        case 0x68:
                            Console.WriteLine("Relay 4 on: 0x68");
                            RelayState |= 0x08;
                            break;
                        case 0x69:
                            Console.WriteLine("Relay 5 on: 0x69");
                            RelayState |= 0x10;
                            break;
                        case 0x6a:
                            Console.WriteLine("Relay 6 on: 0x6a");
                            RelayState |= 0x20;
                            break;
                        case 0x6b:
                            Console.WriteLine("Relay 7 on: 0x6b");
                            RelayState |= 0x40;
                            break;
                        case 0x6c:
                            Console.WriteLine("Relay 8 on: 0x6c");
                            RelayState |= 0x80;
                            break;
                        case 0x6e:
                            Console.WriteLine("All Relays off: 0x6E");
                            RelayState = 0x00;
                            break;
                        case 0x6f: 
                            Console.WriteLine("Relay 1 off: 0x6f");
                            RelayState ^= 0x01;
                            break;
                        case 0x70:
                             Console.WriteLine("Relay 2 off: 0x70");
                            RelayState ^= 0x02;
                            break;
                        case 0x71:
                            Console.WriteLine("Relay 3 off: 0x71");
                            RelayState ^= 0x04;
                            break;
                        case 0x72:
                            Console.WriteLine("Relay 4 off: 0x72");
                            RelayState ^= 0x08;
                            break;
                        case 0x73:
                            Console.WriteLine("Relay 5 off: 0x73");
                            RelayState ^= 0x10;
                            break;
                        case 0x74:
                            Console.WriteLine("Relay 6 off: 0x74");
                            RelayState ^= 0x20;
                            break;
                        case 0x75:
                            Console.WriteLine("Relay 7 off: 0x75");
                            RelayState ^= 0x40;
                            break;
                        case 0x76:
                            Console.WriteLine("Relay 8 off: 0x76");
                            RelayState ^= 0x80;
                            break;
                        case 0x77:
                            Console.WriteLine("Get MAC address: 0x77");
                            handler.Send(new byte[] { 0x7D, 0x45, 0xF3, 0x12, 0xD4, 0x2F });
                            break;

                        default:
                            break;
                    }
                   
                }
            }
            
            //byte[] msg = Encoding.ASCII.GetBytes(data);
            //handler.Send(msg);
            //handler.Shutdown(SocketShutdown.Both);
            //handler.Close();

        }
    }
}
